#!/usr/bin/env python

import rospy
import argparse
from std_msgs.msg import String
import geometry_msgs.msg
import tf
import math
import numpy as np

def polygonProp():

  #-----------------------------------------------------------------------------
  # Initialize node
  #-----------------------------------------------------------------------------

  rospy.init_node('prop_polygon', anonymous=False)

  # This code is required to make sure this node gets simulation time correctly
  simulation = False
  if rospy.has_param('/use_sim_time'):
    if rospy.get_param("/use_sim_time") == True:
      simulation = True

  if simulation:
    rospy.loginfo("Using simulated time.")
    rospy.loginfo("Waiting for the first valid time measurement...")
    t = rospy.Time.now()
    while t == rospy.Time.from_sec(0):
      t = rospy.Time.now()
    rospy.loginfo("Done!")

  else:
    rospy.loginfo("Using real time.")

  #-----------------------------------------------------------------------------
  # Parse command line
  #-----------------------------------------------------------------------------

  parser = argparse.ArgumentParser(description='Polygon Drive Proportional Control')
  parser.add_argument('-d',      default=1.5, type=float)
  parser.add_argument('-n',      default=6, type=int)

  args = parser.parse_args()
  sideLength = args.d
  numSides = args.n

  rospy.loginfo("Polygon parameters:")
  rospy.loginfo("  number of sides: " + str (numSides))
  rospy.loginfo("  side length: " + str(sideLength))

  #-----------------------------------------------------------------------------
  # Drive (your code should go here)
  #-----------------------------------------------------------------------------

  # Initialize transform listener
  tfListener = tf.TransformListener()

  # Get current transform between robot base and robot start point
  tf_upAndRunning = False
  while tf_upAndRunning == False:
    try:
      (position, orientation) = tfListener.lookupTransform("/odom", "/base_footprint", rospy.Time(0))
      tf_upAndRunning = True
      rospy.loginfo('Tf is up and running.')
    except:
      rospy.loginfo('Ran into exception!')

  #Messgaes will be published on topic... & message type will be...
  pub = rospy.Publisher('/cmd_vel_mux/input/navi',geometry_msgs.msg.Twist, queue_size=10)

  #Parameters: linear velocity (v) in m/s and angular velocity (w) in rad/s
  v_max = 0.2
  w_max = 0.5

  # On simulation: Gazebo
  k_rho = 1.1
  k_alpha = 1.5
  k_beta = -0.075

  # # On Real Turtlebot
  # k_rho = 0.6
  # k_alpha = 0.9
  # k_beta = -0.075

  #Message for movement along the polygon
  msg1 = geometry_msgs.msg.Twist()

  #Sending a message (msg) for amount of time (number_of_seconds)
  def send_msg_block(number_of_seconds,msg):

    r = rospy.Rate(10)
    t = rospy.Time.now()

    while rospy.Time.now() - t < rospy.Duration(number_of_seconds):
      pub.publish(msg)
      r.sleep()

  # To obtain the current location of robot
  def get_position():

    (position, orientation) = tfListener.lookupTransform("/odom", "/base_footprint", rospy.Time(0))
    orientation_euler = tf.transformations.euler_from_quaternion(orientation)
    # rospy.loginfo('Position:')
    # rospy.loginfo(position)
    # rospy.loginfo('Orientation:')
    # rospy.loginfo(orientation) 
    # rospy.loginfo('Orientation in euler:')
    # rospy.loginfo(orientation_euler)

    (x,y,theta) = position
    (angle_x,angle_y,angle_z) = orientation_euler

    return x, y, theta, angle_x, angle_y, angle_z

  def get_poly_waypoints(numSides,sideLength):

    (x, y, theta, angle_x, angle_y, angle_z) = get_position()
    DEG2RAD = math.pi/180
    delta_theta = (360/numSides)*DEG2RAD
    initial_pose = [x, y, angle_z]
    poly_wp = []
    prev_pose = initial_pose
    curr_angle = initial_pose[2]

    for i in range(numSides):

      x_pose = prev_pose[0] + sideLength*math.cos(curr_angle)
      y_pose = prev_pose[1] + sideLength*math.sin(curr_angle)
      curr_angle = prev_pose[2]

      if curr_angle > 180*DEG2RAD:
        curr_angle = curr_angle - 360*DEG2RAD
      
      poly_wp.append([x_pose, y_pose, angle_z])
      angle_z = angle_z + delta_theta
      curr_angle = prev_pose[2] + delta_theta
      prev_pose = [x_pose, y_pose, curr_angle]

    return poly_wp

  def get_wp2():
    wp = []
    (x, y, theta, angle_x, angle_y, angle_z) = get_position()
    x_goal = x + (sideLength*math.cos(angle_z))
    y_goal = y + (sideLength*math.sin(angle_z))
    wp1 = [x_goal,y_goal,angle_z]
    wp2 = [wp1[0], wp1[1]+sideLength, angle_z+90*math.pi/180]
    wp3 = [wp2[0]-sideLength, wp2[1], angle_z+180*math.pi/180]
    wp4 = [x, y, angle_z+270*math.pi/180]

    wp.append(wp1)
    wp.append(wp2)
    wp.append(wp3)
    wp.append(wp4)
    return wp 

  rospy.loginfo('------------------------------------------------')
  rospy.loginfo('Turtle bot start')
  (x, y, theta, angle_x, angle_y, angle_z) = get_position()
  # wp = get_wp(numSides,sideLength)
  wp_2 = get_wp2()
  print wp_2
  wp = get_poly_waypoints(numSides,sideLength)
  print '\n\n'
  print wp
  rospy.loginfo('------------------------------------------------')

  for i in range(0,numSides):

    # rospy.loginfo('------------------------------------------------')
    # rospy.loginfo('Iteration number:%i',i+1)
    # rospy.loginfo('------------------------------------------------')

    (x_goal, y_goal, angle_goal) = wp[i]
    if angle_goal > math.pi:
      angle_goal = angle_goal - 2*math.pi

    if x_goal < 0.00001:
      if x_goal > 0:
        x_goal = 0

    if y_goal < 0.00001:
      if y_goal > 0:
        y_goal = 0

    print '------------------------------------------------'
    print "Curr Waypoint: ", i, x_goal, y_goal
    print '------------------------------------------------'
    # rospy.loginfo('Goal:')
    # rospy.loginfo(wp[i])

    #rho, alpha and beta calculations:
    rho = math.sqrt( math.pow((x_goal-x),2) + math.pow((y_goal-y),2) )
    # rospy.loginfo('Value of rho: %f',rho)

    theta_direction=math.atan2((y_goal-y),(x_goal-x))
    # rospy.loginfo('Value of theta_direction: %f', theta_direction)
    alpha = theta_direction - angle_z
    beta = - theta_direction
    print "Before Angle To Goal: ", theta_direction*180/math.pi, angle_z*180/math.pi
    print "Before Alpha and Beta: ", alpha, beta
    # rospy.loginfo('Value of alpha: %f',alpha)

    # rospy.loginfo('Motion starts now')

    flag_continue = True
    
    while True:

      msg1.linear.x = k_rho * rho

      alpha = ((alpha + math.pi) %(2*math.pi)) - math.pi
      beta = ((beta + math.pi)%(2 * math.pi)) - math.pi
      
      msg1.angular.z = (k_alpha*alpha) + (k_beta*beta)

      if msg1.linear.x > v_max:
        msg1.linear.x = v_max

      if msg1.angular.z > w_max:
        msg1.angular.z = w_max
      
      if msg1.angular.z < -w_max:
          msg1.angular.z = -w_max

      print "V Value Sent: ", msg1.linear.x 
      print "Rot Value Sent: ", msg1.angular.z

      if (abs(rho)) < 0.2:
        print '------ DISTANCE STATISFIED --------'

      if (abs(((angle_goal - angle_z + math.pi) % (2 * math.pi)) - math.pi) < 0.4):
        print '------ ANGLE STATISFIED --------'

      if (abs(((angle_goal - angle_z + math.pi) % (2 * math.pi)) - math.pi) < 0.4) and abs(rho) < 0.2:
        break
        
      print 'LINEAR velocity: ', msg1.linear.x
      print 'ANGULAR velocity: ',msg1.angular.z
      send_msg_block(0.001,msg1)

      (x, y, theta, angle_x, angle_y, angle_z) = get_position()

      rho = math.sqrt((x_goal-x)**2 + (y_goal-y)**2)

      theta_direction=math.atan2((y_goal-y),(x_goal-x))
      alpha = theta_direction - angle_z
      beta = -theta_direction

      print "Angle To Goal: ", theta_direction*180/math.pi, angle_z*180/math.pi
      print "Alpha and Beta: ", alpha, beta

      print "- > > - > > ERROR: ", rho, abs((angle_goal - angle_z + math.pi) % 2*math.pi - math.pi)
      # alpha, theta_direction*180/math.pi, angle_z*180/math.pi
      print "POSE: ", x, y, angle_z*180/math.pi
      print "GOAL: ",i , x_goal, y_goal, angle_goal*180/math.pi
      # rospy.loginfo('Value of alpha: %f',alpha)

    rospy.loginfo('Motion ends.')
    rospy.loginfo('------------------------------------------------')

  #


#-------------------------------------------------------------------------------
# Main
#-------------------------------------------------------------------------------

if __name__ == '__main__':
  try:
    polygonProp()
  except rospy.ROSInterruptException:
    pass